# Editor de Texto en Unix — Sistemas Operativos (SO2026B, EAFIT)

Proyecto de la Evaluación Práctica (primer parcial) de Sistemas Operativos.
Equipo de **3 integrantes** → nivel de exigencia acumulado: Base (individual) +
Nivel 2 (parejas) + Nivel 3 (tres integrantes).

## Idea general

El editor **es el editor de texto visual compartido por el profesor**
(`editorEAFIT`): un editor de pantalla completa en modo raw (como `vi`/`nano`),
con su propia estructura de datos en memoria (lista enlazada de líneas y
palabras) y su barra de estado. No se reemplazó ni se reescribió: se **extendió**
agregándole un modo de órdenes de línea (activado con `:`, igual que en `vi`)
donde viven los 10 comandos que pide la guía (`o p a d q i s m y x`), todos
implementados con las syscalls POSIX de bajo nivel que exige el enunciado.

```
shell/eafitOS  --fork()+execvp()-->  editor/text_editor
     (proceso padre)                     (proceso hijo)
     espera con waitpid()          editor visual del profesor + modo ":" (ordenes.c)
```

## Qué hay en esta carpeta

```
proyecto/
├── README.md            # este archivo
├── INFORME.md / .pdf    # documento de sustentación
├── PRUEBAS.sh           # script de pruebas automatizado (pseudo-terminal)
├── Makefile              # compila editor/ y shell/ por separado
├── tests/
│   └── pty_driver.c    # driver de pruebas sobre pseudo-terminal (modo raw)
├── editor/               # editor de texto del profesor + modo de ordenes
│   ├── main.c            # bucle principal (SIN modificar): raw mode + refrescar pantalla
│   ├── terminal.c/.h      # modo raw de la terminal, tamaño de ventana (SIN modificar)
│   ├── estructura.c/.h    # lista enlazada de lineas/palabras en memoria
│   ├── editor.c/.h        # dibujo de pantalla, barra de estado, carga/guardado inicial
│   ├── comando.c/.h       # atajos Ctrl+? del editor visual + entrada al modo ":"
│   └── ordenes.c/.h       # NUEVO: modo de ordenes ":" -> o p a d q i s m y x
└── shell/                 # shell del profesor (SO2026B)
    ├── main.c, shell.h, cat_datos.c, cat_memoria.c, cat_monitoreo.c, cat_util.c
    │   (codigo original del profesor, sin modificar su logica)
    └── cat_editor.c       # NUEVO: comando ed_open que lanza el editor como proceso hijo
```

## Compilar

```bash
cd proyecto
make editor      # genera editor/text_editor
make shell       # genera shell/eafitOS (y lo ejecuta automaticamente al terminar)
```

Se compilan por separado porque el Makefile del shell (heredado del profesor)
ejecuta el binario apenas termina de compilar. Para limpiar todo: `make clean`.

## Ejecutar

**Standalone** (sin pasar por el shell):

```bash
cd editor
./text_editor archivo.txt
```

Se abre el editor visual normal del profesor (flechas/WASD para moverse,
Ctrl-S guarda, Ctrl-Q sale, Ctrl-H ayuda, Ctrl-F buscar).
Presionando `:` se entra al **modo de ordenes**, igual que en `vi`.

**Integrado con el shell del profesor** (forma prevista de uso):

```bash
cd shell
./eafitOS
eafitOS> ed_open archivo.txt
```

`ed_open` lanza `../editor/text_editor` como proceso hijo (`fork` + `execvp` +
`waitpid`, igual que hace `p_exec` en el shell original). Al salir del editor
con `:q`, el control vuelve al prompt del shell. Ver `INFORME.md` para la
justificación completa de la decisión de arquitectura.

## El modo de ordenes (`:`)

Desde el editor visual, presionar `:` limpia la pantalla, sale del modo raw y
muestra un prompt de texto normal:

```
=== MODO DE ORDENES (evaluacion SO2026B) ===
Archivo actual: archivo.txt (abierto)
Orden (o/p/a/d/q/i/s/m/y/x, o 'help'):
```

| Comando | Descripcion | Nivel | Syscalls principales |
|---|---|---|---|
| `o <archivo>` | Abre o crea el archivo | Base | `open` |
| `p [n]` | Imprime la linea `n`, o todo el archivo sin argumento | Base | `lseek`, `read`, `write` |
| `a <texto>` | Anade `texto` como nueva linea al final | Base | `lseek(SEEK_END)`, `write` |
| `d <n>` | Borra la linea `n` | Base | `read`, `write`, `lseek`, `ftruncate` |
| `q` | Cierra el archivo y sale | Base | `close`, `exit` |
| `i <n> <texto>` | Inserta `texto` como linea `n`, desplazando el resto | Nivel 2 | `lseek`, `read`, `write` |
| `s <palabra>` | Busca `palabra` en todo el archivo | Nivel 2 | `lseek`, `read` |
| `m` | Muestra metadatos del archivo (tamano, permisos, inodo, fecha) | Nivel 3 | `fstat` |
| `y <n>` | Copia la linea `n` al portapapeles | Nivel 3 | `lseek`, `read` |
| `x <n>` | Pega el portapapeles como linea `n` | Nivel 3 | `lseek`, `read`, `write` |

El texto con espacios debe ir entre comillas: `a "hola mundo"`. Tras ejecutar
la orden, presionar ENTER vuelve al modo visual, que se recarga automaticamente
desde el archivo en disco para reflejar el cambio (excepto `p`, `s` y `m`, que
solo consultan y no modifican nada).

## Pruebas

```bash
./PRUEBAS.sh
```

Compila ambos binarios y ejecuta automaticamente, mediante un pseudo-terminal
real (`tests/pty_driver.c`, necesario porque el editor lee el teclado en modo
raw byte a byte), la secuencia completa de comandos: base, nivel 2, nivel 3,
manejo de errores, e integracion con el shell via `ed_open`. Verifica tanto lo
que aparece en pantalla como el contenido real del archivo en disco.

## Restriccion de E/S

Todo el acceso al archivo de texto (abrir, leer, escribir, truncar, cerrar,
consultar metadatos) se hace exclusivamente con `open`, `read`, `write`,
`lseek`, `ftruncate`, `close` y `fstat` — nunca `fopen`/`fread`/`fwrite`/`fclose`.
Solo se usa E/S estandar (`printf`, `fgets`) para leer ordenes desde `STDIN` e
imprimir mensajes en `STDOUT` dentro del modo de ordenes, tal como exige el
enunciado.

## Alcance (equipo de 3 integrantes)

Se implementa **Base + Nivel 2 + Nivel 3** (10 comandos). Deliberadamente
**no** se implementan Nivel 4 (undo/redo con archivos de intercambio en `/tmp`
y `unlink()`) ni Nivel 5 (multi-buffer y bloqueo con `fcntl`), porque esos
niveles corresponden a equipos de 4 y 5 integrantes respectivamente.
