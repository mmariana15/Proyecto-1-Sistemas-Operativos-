#ifndef TERMINAL_H
#define TERMINAL_H

// Modulo: control de bajo nivel de la terminal (modo raw + tamano de ventana).

void terminal_activar_modo_raw();     // pone la terminal en modo raw (byte a byte)
void terminal_desactivar_modo_raw();  // restaura la terminal a su estado original
int terminal_obtener_tamano(int *filas, int *columnas); // consulta filas/columnas via ioctl

#endif
