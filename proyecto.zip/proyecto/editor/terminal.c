#include "terminal.h"
#include <termios.h>   // Para las estructuras y funciones de control de la terminal (tcgetattr, tcsetattr)
#include <unistd.h>    // Para constantes de descriptores de archivos del estándar POSIX (STDIN_FILENO, etc.)
#include <stdlib.h>    // Para utilidades estándar, como registrar funciones de limpieza al salir (atexit)
#include <sys/ioctl.h> // Para la llamada al sistema ioctl() que permite consultar dimensiones de la ventana (TIOCGWINSZ)

// Guardamos el estado original de la terminal para restaurarlo al salir.
struct termios termios_original;

/* El "modo raw" apaga el procesamiento normal del TTY (esperar ENTER, eco
 * automatico de teclas, señales como Ctrl+C) para que el editor reciba
 * cada tecla apenas se presiona, byte a byte. */

// Restaura la configuracion original de la terminal (se llama al salir).
void terminal_desactivar_modo_raw() {
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &termios_original);
}

// Activa el modo raw: desactiva ICANON (esperar ENTER), ECHO (eco de
// teclas), ISIG (Ctrl+C/Ctrl+Z) e IXON (Ctrl+S/Ctrl+Q), y hace que read()
// se bloquee hasta recibir al menos 1 byte, sin timeout.
void terminal_activar_modo_raw() {
    tcgetattr(STDIN_FILENO, &termios_original);
    atexit(terminal_desactivar_modo_raw); // por si el programa termina solo

    struct termios raw = termios_original;
    raw.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
    raw.c_oflag &= ~(OPOST);
    raw.c_cflag |= (CS8);
    raw.c_lflag &= ~(ECHO | ICANON | IEXTEN | ISIG);
    raw.c_cc[VMIN] = 1;
    raw.c_cc[VTIME] = 0;

    tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw);
}

// Consulta al kernel (via ioctl/TIOCGWINSZ) el tamano actual de la ventana
// de la terminal, para saber cuantas filas/columnas hay disponibles.
int terminal_obtener_tamano(int *filas, int *columnas) {
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == -1 || ws.ws_col == 0) {
        return -1;
    } else {
        *columnas = ws.ws_col;
        *filas = ws.ws_row;
        return 0;
    }
}
