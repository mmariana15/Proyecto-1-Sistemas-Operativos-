#ifndef COMANDO_H
#define COMANDO_H

#include "editor.h"

// Ctrl+[letra] en la terminal genera el codigo ASCII de la letra con los 3
// bits mas significativos apagados (AND con 0x1f). Ej: TECLA_CTRL('q') = Ctrl+Q.
#define TECLA_CTRL(k) ((k) & 0x1f)

// Despacha atajos de teclado (Ctrl+S/Q/H/F, ':'). Retorna 1 si consumio la
// tecla como comando, 0 si debe tratarse como texto normal.
int comando_manejar_teclado(char c, EstadoEditor *e);

// Muestra una pantalla de log (ej. traza de guardar/cargar archivo) y
// bloquea hasta que el usuario presiona ENTER.
void comando_mostrar_log_sistema(const char *titulo, const char *log);

// Si el modal de ayuda esta activo (Ctrl+H), lo dibuja en vez del texto normal.
// Retorna 1 si se dibujo un modal, 0 si no hay ninguno activo.
int comando_dibujar_modal(EstadoEditor *e);

#endif
