#ifndef EDITOR_H
#define EDITOR_H

#include "estructura.h"

// Colores ANSI del tema visual del editor.
#define TEMA_FONDO         "\x1b[49m"   // Fondo de la terminal (49 = Defecto)
#define TEMA_TEXTO         "\x1b[39m"   // Color del texto principal (39 = Defecto)
#define TEMA_BARRA_ESTADO  "\x1b[7m"    // Barra inferior invertida
#define TEMA_LINEA_VACIA   "~"          // Símbolo para las líneas vacías al final
#define TEMA_RESTAURAR     "\x1b[0m"    // Restablece todos los formatos

// Estado global de una sesion de edicion (cursor, archivo abierto, etc.).
typedef struct {
    EstructuraTexto *estructura;    // Estructura de datos (Modelo)
    int cursorX;              // Posición lógica del cursor (Columnas)
    int cursorY;              // Posición lógica del cursor (Filas)
    int filasPantalla;        // Límite visual de la ventana
    int columnasPantalla;     // Límite visual de la ventana
    NodoLinea *lineaActual;   // Referencia rápida al nodo donde estamos escribiendo
    char *nombreArchivo;      // Ruta del archivo abierto
    int mostrarAyuda;         // Bandera booleana de UI (modal de ayuda, Ctrl+H)
    int desplazamientoFila;   // Desplazamiento (Scroll) vertical

    int fdArchivo; // descriptor persistente del modo de ordenes (':'); -1 si no hay archivo abierto
} EstadoEditor;

// Funciones del ciclo de vida y renderizado
void editor_inicializar(EstadoEditor *e, const char* nombreArchivo);
void editor_liberar(EstadoEditor *e);
void editor_refrescar_pantalla(EstadoEditor *e);
void editor_procesar_tecla(EstadoEditor *e);

// Funciones expuestas del UI para el procesamiento de comandos
void editor_pantalla_limpiar(void);

// Muestra una pantalla de bienvenida al arrancar
void editor_pantalla_bienvenida(EstadoEditor *e);

// Mueve el cursor logico al final del documento (se usa tras recargar la
// estructura desde disco, por ejemplo despues de 'a', 'd', 'i', 'x').
void editor_reposicionar_cursor_final(EstadoEditor *e);

#endif
