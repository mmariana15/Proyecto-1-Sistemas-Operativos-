#include "ordenes.h"
#include "terminal.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <sys/stat.h>
#include <time.h>

/* Portapapeles secuencial local para 'y' (yank) / 'x' (paste), nivel 3. */
static char *g_portapapeles = NULL;

// Separa una linea de orden en tokens por espacios, admitiendo texto con
// espacios entre comillas dobles (ej: a "hola mundo"). Igual en espiritu
// al parse_line() del shell del profesor.
static int tokenizar(char *linea, char **argv, int max_args) {
    int argc = 0;
    char *p = linea;
    int en_comillas = 0;
    char *inicio = NULL;

    while (*p) {
        if (!en_comillas && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) {
            if (inicio) { *p = '\0'; if (argc < max_args) argv[argc++] = inicio; inicio = NULL; }
        } else if (*p == '"') {
            if (en_comillas) { *p = '\0'; if (argc < max_args) argv[argc++] = inicio; inicio = NULL; en_comillas = 0; }
            else { en_comillas = 1; inicio = p + 1; }
        } else {
            if (!inicio) inicio = p;
        }
        p++;
    }
    if (inicio && argc < max_args) argv[argc++] = inicio;
    return argc;
}

// Recarga la estructura en memoria desde el fd persistente y reposiciona el
// cursor al final. Se llama tras cualquier orden que modifique el archivo
// (a, d, i, x) para que el modo visual siempre refleje lo que hay en disco.
static void recargar_estructura(EstadoEditor *e) {
    if (e->fdArchivo == -1) return;
    estructura_destruir(e->estructura);
    e->estructura = estructura_crear();
    estructura_cargar_desde_fd(e->estructura, e->fdArchivo, NULL);
    editor_reposicionar_cursor_final(e);
}

// o <archivo>  ->  Abre/crea el archivo (Base)
// Syscall: open() con O_RDWR|O_CREAT
static void cmd_o(EstadoEditor *e, int argc, char **argv) {
    if (argc != 2) { printf("Uso: o <archivo>\n"); return; }

    if (e->fdArchivo != -1) {
        printf("[syscall] close(%d)\n", e->fdArchivo);
        close(e->fdArchivo);
        e->fdArchivo = -1;
    }

    printf("[syscall] open(\"%s\", O_RDWR|O_CREAT, 0644) ... ", argv[1]);
    int fd = open(argv[1], O_RDWR | O_CREAT, 0644);
    if (fd == -1) { printf("= -1\n"); perror("open"); return; }
    printf("= %d\n", fd);
    e->fdArchivo = fd;

    free(e->nombreArchivo);
    e->nombreArchivo = strdup(argv[1]);

    estructura_destruir(e->estructura);
    e->estructura = estructura_crear();
    estructura_cargar_desde_fd(e->estructura, e->fdArchivo, NULL);
    editor_reposicionar_cursor_final(e);

    printf("Archivo '%s' abierto (fd=%d), %d linea(s) cargada(s) en memoria.\n",
           e->nombreArchivo, e->fdArchivo, e->estructura->totalLineas);
}

// p [n]  ->  Imprime la linea n, o todo el archivo sin argumento (Base)
// Syscalls: lseek(), read(), write() (FD 1)
static void cmd_p(EstadoEditor *e, int argc, char **argv) {
    if (e->fdArchivo == -1) { printf("No hay archivo abierto. Use: o <archivo>\n"); return; }

    if (argc == 1) {
        printf("[syscall] lseek(%d, 0, SEEK_SET)\n", e->fdArchivo);
        if (lseek(e->fdArchivo, 0, SEEK_SET) == -1) { perror("lseek"); return; }
        char buf[512];
        ssize_t n;
        printf("--- Contenido del archivo ---\n");
        while ((n = read(e->fdArchivo, buf, sizeof(buf))) > 0) {
            write(STDOUT_FILENO, buf, (size_t)n);
        }
        printf("\n--- Fin del archivo ---\n");
        return;
    }
    if (argc != 2) { printf("Uso: p [n]\n"); return; }

    int objetivo = atoi(argv[1]);
    if (objetivo <= 0) { printf("Numero de linea invalido (debe ser >= 1).\n"); return; }

    if (lseek(e->fdArchivo, 0, SEEK_SET) == -1) { perror("lseek"); return; }
    char buf[4096];
    ssize_t n;
    int linea_actual = 1;
    char linebuf[4096];
    int pos = 0;
    int encontrada = 0;

    while ((n = read(e->fdArchivo, buf, sizeof(buf))) > 0) {
        for (ssize_t i = 0; i < n; i++) {
            if (linea_actual == objetivo) {
                encontrada = 1;
                if (buf[i] == '\n') {
                    linebuf[pos] = '\0';
                    printf("Linea %d: %s\n", objetivo, linebuf);
                    return;
                }
                if (pos < (int)sizeof(linebuf) - 1) linebuf[pos++] = buf[i];
            } else if (buf[i] == '\n') {
                linea_actual++;
            }
        }
    }
    if (encontrada) {
        linebuf[pos] = '\0';
        printf("Linea %d: %s\n", objetivo, linebuf);
    } else {
        printf("La linea %d no existe en el archivo.\n", objetivo);
    }
}

// a <texto>  ->  Anade texto como nueva linea al final (Base)
// Syscalls: lseek(SEEK_END), write()
static void cmd_a(EstadoEditor *e, int argc, char **argv) {
    if (e->fdArchivo == -1) { printf("No hay archivo abierto. Use: o <archivo>\n"); return; }
    if (argc != 2) { printf("Uso: a <texto>\n"); return; }

    printf("[syscall] lseek(%d, 0, SEEK_END)\n", e->fdArchivo);
    off_t tam = lseek(e->fdArchivo, 0, SEEK_END);
    if (tam == -1) { perror("lseek"); return; }

    // Si el archivo no esta vacio y su ultimo byte no es '\n' (caso borde:
    // archivo cuya ultima linea no termina en salto de linea), se agrega uno
    // antes del texto nuevo para que no quede pegado a la linea anterior.
    if (tam > 0) {
        char ultimo;
        if (lseek(e->fdArchivo, tam - 1, SEEK_SET) == -1) { perror("lseek"); return; }
        if (read(e->fdArchivo, &ultimo, 1) == -1) { perror("read"); return; }
        if (lseek(e->fdArchivo, 0, SEEK_END) == -1) { perror("lseek"); return; }
        if (ultimo != '\n') {
            if (write(e->fdArchivo, "\n", 1) == -1) { perror("write"); return; }
        }
    }

    size_t len = strlen(argv[1]);
    printf("[syscall] write(%d, texto, %zu)\n", e->fdArchivo, len);
    if (write(e->fdArchivo, argv[1], len) == -1) { perror("write"); return; }
    if (write(e->fdArchivo, "\n", 1) == -1) { perror("write"); return; }

    recargar_estructura(e);
    printf("Linea anadida correctamente.\n");
}

// Lee todo el contenido del fd hacia un buffer dinamico (el llamador debe free()).
static char *leer_archivo_completo(int fd, size_t *tam_out) {
    if (lseek(fd, 0, SEEK_SET) == -1) { perror("lseek"); return NULL; }
    size_t capacidad = 4096, tam = 0;
    char *buf = malloc(capacidad);
    if (!buf) return NULL;
    char tmp[4096];
    ssize_t n;
    while ((n = read(fd, tmp, sizeof(tmp))) > 0) {
        if (tam + (size_t)n > capacidad) {
            capacidad *= 2;
            char *nuevo = realloc(buf, capacidad);
            if (!nuevo) { free(buf); return NULL; }
            buf = nuevo;
        }
        memcpy(buf + tam, tmp, (size_t)n);
        tam += (size_t)n;
    }
    if (n == -1) { perror("read"); free(buf); return NULL; }
    *tam_out = tam;
    return buf;
}

// d <n>  ->  Borra la linea n (Base)
// Syscalls: read(), write(), lseek(), ftruncate()
static void cmd_d(EstadoEditor *e, int argc, char **argv) {
    if (e->fdArchivo == -1) { printf("No hay archivo abierto. Use: o <archivo>\n"); return; }
    if (argc != 2) { printf("Uso: d <n>\n"); return; }

    int objetivo = atoi(argv[1]);
    if (objetivo <= 0) { printf("Numero de linea invalido (debe ser >= 1).\n"); return; }

    size_t tam;
    char *buf = leer_archivo_completo(e->fdArchivo, &tam);
    if (!buf) { printf("Error: no se pudo leer el archivo (ver detalle arriba).\n"); return; }

    int linea_actual = 1;
    size_t inicio = 0, fin = 0;
    int encontrada = 0;
    for (size_t i = 0; i < tam; i++) {
        if (linea_actual == objetivo && !encontrada) { inicio = i; encontrada = 1; }
        if (encontrada && buf[i] == '\n') { fin = i + 1; break; }
        if (buf[i] == '\n' && linea_actual < objetivo) linea_actual++;
    }
    if (!encontrada) { printf("La linea %d no existe en el archivo.\n", objetivo); free(buf); return; }
    if (fin == 0) fin = tam;

    size_t nuevo_tam = tam - (fin - inicio);
    char *nuevo = malloc(nuevo_tam > 0 ? nuevo_tam : 1);
    if (!nuevo) { printf("Error: no hay memoria suficiente.\n"); free(buf); return; }
    memcpy(nuevo, buf, inicio);
    memcpy(nuevo + inicio, buf + fin, tam - fin);

    printf("[syscall] lseek(%d, 0, SEEK_SET)\n", e->fdArchivo);
    if (lseek(e->fdArchivo, 0, SEEK_SET) == -1) { perror("lseek"); free(buf); free(nuevo); return; }
    printf("[syscall] write(%d, buffer, %zu)\n", e->fdArchivo, nuevo_tam);
    if (write(e->fdArchivo, nuevo, nuevo_tam) == -1) { perror("write"); free(buf); free(nuevo); return; }
    printf("[syscall] ftruncate(%d, %zu)\n", e->fdArchivo, nuevo_tam);
    if (ftruncate(e->fdArchivo, nuevo_tam) == -1) { perror("ftruncate"); free(buf); free(nuevo); return; }

    free(buf);
    free(nuevo);
    recargar_estructura(e);
    printf("Linea %d borrada correctamente.\n", objetivo);
}

// Inserta "texto" como nueva linea en la posicion "objetivo" (1-indexado)
// del archivo. La comparten 'i' (texto del usuario) y 'x' (portapapeles).
static void insertar_linea_en_fd(EstadoEditor *e, int objetivo, const char *texto) {
    size_t tam;
    char *buf = leer_archivo_completo(e->fdArchivo, &tam);
    if (!buf) { printf("Error: no se pudo leer el archivo (ver detalle arriba).\n"); return; }

    int linea_actual = 1;
    size_t pos_insercion = 0;
    if (objetivo == 1) {
        pos_insercion = 0;
    } else {
        int hallada = 0;
        for (size_t i = 0; i < tam; i++) {
            if (buf[i] == '\n') {
                linea_actual++;
                if (linea_actual == objetivo) { pos_insercion = i + 1; hallada = 1; break; }
            }
        }
        if (!hallada) {
            printf("La linea %d no existe en el archivo.\n", objetivo);
            free(buf);
            return;
        }
    }

    size_t len_texto = strlen(texto);
    size_t nuevo_tam = tam + len_texto + 1;
    char *nuevo = malloc(nuevo_tam);
    if (!nuevo) { printf("Error: no hay memoria suficiente.\n"); free(buf); return; }

    memcpy(nuevo, buf, pos_insercion);
    memcpy(nuevo + pos_insercion, texto, len_texto);
    nuevo[pos_insercion + len_texto] = '\n';
    memcpy(nuevo + pos_insercion + len_texto + 1, buf + pos_insercion, tam - pos_insercion);

    printf("[syscall] lseek(%d, 0, SEEK_SET)\n", e->fdArchivo);
    if (lseek(e->fdArchivo, 0, SEEK_SET) == -1) { perror("lseek"); free(buf); free(nuevo); return; }
    printf("[syscall] write(%d, buffer, %zu)\n", e->fdArchivo, nuevo_tam);
    if (write(e->fdArchivo, nuevo, nuevo_tam) == -1) { perror("write"); free(buf); free(nuevo); return; }

    free(buf);
    free(nuevo);
    recargar_estructura(e);
}

// i <n> <texto>  ->  Inserta texto como nueva linea n (Nivel 2 - parejas)
// Syscalls: lseek(), read(), write() + buffers dinamicos (malloc/realloc/free)
static void cmd_i(EstadoEditor *e, int argc, char **argv) {
    if (e->fdArchivo == -1) { printf("No hay archivo abierto. Use: o <archivo>\n"); return; }
    if (argc != 3) { printf("Uso: i <n> <texto>\n"); return; }

    int objetivo = atoi(argv[1]);
    if (objetivo <= 0) { printf("Numero de linea invalido (debe ser >= 1).\n"); return; }

    insertar_linea_en_fd(e, objetivo, argv[2]);
    printf("Linea %d insertada correctamente.\n", objetivo);
}

// q  ->  Cierra el descriptor de archivo y sale de la aplicacion (Base)
// Syscalls: close(), exit()
static void cmd_q(EstadoEditor *e, int argc, char **argv) {
    (void)argc; (void)argv;
    if (e->fdArchivo != -1) {
        printf("[syscall] close(%d)\n", e->fdArchivo);
        close(e->fdArchivo);
        e->fdArchivo = -1;
    }
    printf("Cerrando editor. Hasta luego!\n");
    fflush(stdout);
    write(STDOUT_FILENO, TEMA_RESTAURAR, strlen(TEMA_RESTAURAR));
    editor_pantalla_limpiar();
    editor_liberar(e); // libera la lista enlazada y el nombre de archivo antes de salir
    exit(0);
}

// s <palabra>  ->  Busca una palabra en todo el archivo (Nivel 2 - parejas)
// Syscalls: lseek(), read() secuencial (+ strstr() en memoria, no es E/S)
static void cmd_s(EstadoEditor *e, int argc, char **argv) {
    if (e->fdArchivo == -1) { printf("No hay archivo abierto. Use: o <archivo>\n"); return; }
    if (argc != 2) { printf("Uso: s <palabra>\n"); return; }

    printf("[syscall] lseek(%d, 0, SEEK_SET)\n", e->fdArchivo);
    if (lseek(e->fdArchivo, 0, SEEK_SET) == -1) { perror("lseek"); return; }

    char buf[4096];
    ssize_t n;
    int linea_actual = 1;
    char linebuf[4096];
    int pos = 0;
    int alguna = 0;

    printf("--- Resultados de busqueda para '%s' ---\n", argv[1]);
    while ((n = read(e->fdArchivo, buf, sizeof(buf))) > 0) {
        for (ssize_t i = 0; i < n; i++) {
            if (buf[i] == '\n') {
                linebuf[pos] = '\0';
                if (strstr(linebuf, argv[1]) != NULL) {
                    printf("Linea %d: %s\n", linea_actual, linebuf);
                    alguna = 1;
                }
                linea_actual++;
                pos = 0;
            } else if (pos < (int)sizeof(linebuf) - 1) {
                linebuf[pos++] = buf[i];
            }
        }
    }
    if (pos > 0) {
        linebuf[pos] = '\0';
        if (strstr(linebuf, argv[1]) != NULL) { printf("Linea %d: %s\n", linea_actual, linebuf); alguna = 1; }
    }
    if (!alguna) printf("No se encontraron resultados para '%s'.\n", argv[1]);
}

// m  ->  Metadatos del archivo abierto (Nivel 3 - tres integrantes)
// Syscall: fstat()
static void cmd_m(EstadoEditor *e, int argc, char **argv) {
    (void)argc; (void)argv;
    if (e->fdArchivo == -1) { printf("No hay archivo abierto. Use: o <archivo>\n"); return; }

    struct stat st;
    printf("[syscall] fstat(%d, &st) ... ", e->fdArchivo);
    if (fstat(e->fdArchivo, &st) == -1) { printf("= -1\n"); perror("fstat"); return; }
    printf("= 0\n");

    printf("--- Metadatos del archivo ---\n");
    printf("Archivo: %s\n", e->nombreArchivo ? e->nombreArchivo : "?");
    printf("Tamano: %lld bytes\n", (long long)st.st_size);
    printf("Permisos: 0%o\n", st.st_mode & 0777);
    printf("Inodo: %llu\n", (unsigned long long)st.st_ino);
    printf("Ultima modificacion: %s", ctime(&st.st_mtime));
}

// y <n>  ->  Copia (yank) la linea n al portapapeles (Nivel 3)
// Syscalls: lseek(), read()
static void cmd_y(EstadoEditor *e, int argc, char **argv) {
    if (e->fdArchivo == -1) { printf("No hay archivo abierto. Use: o <archivo>\n"); return; }
    if (argc != 2) { printf("Uso: y <n>\n"); return; }

    int objetivo = atoi(argv[1]);
    if (objetivo <= 0) { printf("Numero de linea invalido (debe ser >= 1).\n"); return; }

    if (lseek(e->fdArchivo, 0, SEEK_SET) == -1) { perror("lseek"); return; }
    char buf[4096];
    ssize_t n;
    int linea_actual = 1;
    char linebuf[4096];
    int pos = 0;
    int encontrada = 0;

    while ((n = read(e->fdArchivo, buf, sizeof(buf))) > 0) {
        for (ssize_t i = 0; i < n; i++) {
            if (linea_actual == objetivo) {
                encontrada = 1;
                if (buf[i] == '\n') {
                    linebuf[pos] = '\0';
                    free(g_portapapeles);
                    g_portapapeles = strdup(linebuf);
                    printf("Linea %d copiada al portapapeles.\n", objetivo);
                    return;
                }
                if (pos < (int)sizeof(linebuf) - 1) linebuf[pos++] = buf[i];
            } else if (buf[i] == '\n') {
                linea_actual++;
            }
        }
    }
    if (encontrada) {
        linebuf[pos] = '\0';
        free(g_portapapeles);
        g_portapapeles = strdup(linebuf);
        printf("Linea %d copiada al portapapeles.\n", objetivo);
    } else {
        printf("La linea %d no existe en el archivo.\n", objetivo);
    }
}

// x <n>  ->  Pega el portapapeles como nueva linea n (Nivel 3)
// Syscalls: lseek(), read(), write() (mismo mecanismo que 'i')
static void cmd_x(EstadoEditor *e, int argc, char **argv) {
    if (e->fdArchivo == -1) { printf("No hay archivo abierto. Use: o <archivo>\n"); return; }
    if (g_portapapeles == NULL) { printf("Portapapeles vacio. Use 'y <n>' primero.\n"); return; }
    if (argc != 2) { printf("Uso: x <n>\n"); return; }

    int objetivo = atoi(argv[1]);
    if (objetivo <= 0) { printf("Numero de linea invalido (debe ser >= 1).\n"); return; }

    insertar_linea_en_fd(e, objetivo, g_portapapeles);
    printf("Linea del portapapeles pegada en la linea %d.\n", objetivo);
}

// Imprime la lista de ordenes disponibles (comando 'help' dentro del modo de ordenes).
static void mostrar_ayuda_ordenes(void) {
    printf("Ordenes disponibles:\n");
    printf("  o <archivo>       Abre o crea el archivo             (Base)\n");
    printf("  p [n]             Imprime la linea n, o todo el      (Base)\n");
    printf("                    archivo sin argumento\n");
    printf("  a <texto>         Anade texto como nueva linea al    (Base)\n");
    printf("                    final del archivo\n");
    printf("  d <n>             Borra la linea n                   (Base)\n");
    printf("  q                 Cierra el archivo y sale            (Base)\n");
    printf("  i <n> <texto>     Inserta texto como linea n,        (Nivel 2)\n");
    printf("                    desplazando el resto\n");
    printf("  s <palabra>       Busca la palabra en todo el        (Nivel 2)\n");
    printf("                    archivo\n");
    printf("  m                 Metadatos del archivo (tamano,     (Nivel 3)\n");
    printf("                    permisos, inodo, fecha) via fstat\n");
    printf("  y <n>             Copia la linea n al portapapeles   (Nivel 3)\n");
    printf("  x <n>             Pega el portapapeles como linea n  (Nivel 3)\n");
    printf("  help              Muestra esta ayuda\n");
}

// Enruta el nombre de la orden (argv[0]) a la funcion cmd_* correspondiente.
static void ejecutar_orden(EstadoEditor *e, int argc, char **argv) {
    const char *cmd = argv[0];
    if      (strcmp(cmd, "o") == 0)    cmd_o(e, argc, argv);
    else if (strcmp(cmd, "p") == 0)    cmd_p(e, argc, argv);
    else if (strcmp(cmd, "a") == 0)    cmd_a(e, argc, argv);
    else if (strcmp(cmd, "d") == 0)    cmd_d(e, argc, argv);
    else if (strcmp(cmd, "q") == 0)    cmd_q(e, argc, argv);
    else if (strcmp(cmd, "i") == 0)    cmd_i(e, argc, argv);
    else if (strcmp(cmd, "s") == 0)    cmd_s(e, argc, argv);
    else if (strcmp(cmd, "m") == 0)    cmd_m(e, argc, argv);
    else if (strcmp(cmd, "y") == 0)    cmd_y(e, argc, argv);
    else if (strcmp(cmd, "x") == 0)    cmd_x(e, argc, argv);
    else if (strcmp(cmd, "help") == 0) mostrar_ayuda_ordenes();
    else printf("Orden '%s' no reconocida. Ordenes validas: o p a d q i s m y x (o 'help').\n", cmd);
}

// Punto de entrada del modo de ordenes (tecla ':'): sale del modo raw,
// muestra el prompt, lee y ejecuta UNA orden, y espera ENTER antes de
// volver al modo visual. 'q' es la unica que no retorna: termina el programa.
void ordenes_modo_interactivo(EstadoEditor *e) {
    editor_pantalla_limpiar();
    terminal_desactivar_modo_raw();

    printf("=== MODO DE ORDENES (evaluacion SO2026B) ===\n");
    printf("Archivo actual: %s (%s)\n",
           e->nombreArchivo ? e->nombreArchivo : "[Ninguno]",
           e->fdArchivo != -1 ? "abierto" : "cerrado");
    printf("Orden (o/p/a/d/q/i/s/m/y/x, o 'help'): ");
    fflush(stdout);

    char linea[1024];
    if (fgets(linea, sizeof(linea), stdin) != NULL) {
        char *argv[8];
        int argc = tokenizar(linea, argv, 8);
        if (argc > 0) ejecutar_orden(e, argc, argv);
    }

    printf("\nPresione ENTER para volver al editor...");
    fflush(stdout);
    getchar();

    terminal_activar_modo_raw();
}
