#include "comando.h"
#include "terminal.h"
#include "ordenes.h" // NUEVO: modo de ordenes (o/p/a/d/q/i/s/m/y/x) de la evaluacion
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h> // Para printf, fgets, etc.

// ============================================================================
// FUNCIONES DE UI PROPIAS DE COMANDOS
// ============================================================================

// Sale del modo raw, muestra un log de texto (ej. traza de guardar/cargar),
// y espera ENTER antes de volver al modo raw.
void comando_mostrar_log_sistema(const char *titulo, const char *log) {
    editor_pantalla_limpiar();
    terminal_desactivar_modo_raw();
    printf("\x1b[1;36m==== %s ====\x1b[0m\n\n", titulo);
    printf("%s\n", log);
    printf("\n\x1b[1;33mPresione ENTER para continuar...\x1b[0m");
    fflush(stdout);
    getchar();
    terminal_activar_modo_raw();
}

// Dibuja el menu de ayuda con los atajos y comandos disponibles.
static void comando_dibujar_ayuda(void) {
    char *texto = 
        "=================================================\r\n"
        "            AYUDA DE COMANDOS DEL EDITOR         \r\n"
        "=================================================\r\n\r\n"
        "  Ctrl + S : Guardar el documento actual (modo visual)\r\n"
        "  Ctrl + Q : Salir del editor\r\n"
        "  Ctrl + H : Mostrar / Ocultar esta ayuda\r\n"
        "  Ctrl + F : Buscar palabra (modo visual)\r\n\r\n"
        "  Flechas  : Navegar por el texto\r\n"
        "  W A S D  : Navegación alternativa\r\n\r\n"
        "  :        : Entrar al MODO DE ORDENES de la evaluacion:\r\n"
        "             o <archivo>       abre/crea archivo      (Base)\r\n"
        "             p [n]             imprime linea n o todo (Base)\r\n"
        "             a <texto>         anade linea al final   (Base)\r\n"
        "             d <n>             borra linea n          (Base)\r\n"
        "             q                 cierra y sale          (Base)\r\n"
        "             i <n> <texto>     inserta linea n        (Nivel 2)\r\n"
        "             s <palabra>       busca palabra          (Nivel 2)\r\n"
        "             m                 metadatos (fstat)      (Nivel 3)\r\n"
        "             y <n> / x <n>     copiar / pegar linea   (Nivel 3)\r\n"
        "             (usan open/read/write/lseek/ftruncate/fstat)\r\n"
        "             escriba 'help' dentro del modo para ver esta lista\r\n\r\n"
        "=================================================\r\n"
        "Presiona 'Ctrl + H' para volver a la edición...\r\n";
    write(STDOUT_FILENO, texto, strlen(texto));
}

// Si hay un modal activo (por ahora solo el de ayuda), lo dibuja y retorna 1.
int comando_dibujar_modal(EstadoEditor *e) {
    if (e->mostrarAyuda) { comando_dibujar_ayuda(); return 1; }
    return 0;
}

// ============================================================================
// FUNCIONES MANEJADORAS INDIVIDUALES (Módulos de Comando)
// ============================================================================

// Activa/desactiva la ayuda (Ctrl+H).
static void comando_toggle_ayuda(EstadoEditor *e) {
    e->mostrarAyuda = !e->mostrarAyuda;
}

// Cierra el fd abierto (si hay), restaura los colores de la terminal y sale (Ctrl+Q).
static void comando_salir(EstadoEditor *e) {
    // Cerramos también el descriptor persistente del modo de órdenes (si
    // quedó abierto) para no dejar fugas de descriptores de archivo.
    if (e->fdArchivo != -1) { close(e->fdArchivo); e->fdArchivo = -1; }
    // Restaurar tema original de la terminal del usuario antes de salir
    write(STDOUT_FILENO, TEMA_RESTAURAR, strlen(TEMA_RESTAURAR));
    editor_pantalla_limpiar(); 
    editor_liberar(e); // libera la lista enlazada y el nombre de archivo antes de salir
    exit(0);
}

// Guarda el documento en disco (Ctrl+S) y muestra la traza de syscalls usadas.
static void comando_guardar(EstadoEditor *e) {
    char *log_syscall = malloc(65536);
    log_syscall[0] = '\0';
    estructura_guardar_archivo(e->estructura, e->nombreArchivo, log_syscall);
    comando_mostrar_log_sistema("REPORTE DETALLADO (GUARDAR ARCHIVO)", log_syscall);
    free(log_syscall);
}

// Pide una palabra por teclado (Ctrl+F) y mueve el cursor hasta ella si la encuentra.
static void comando_buscar(EstadoEditor *e) {
    editor_pantalla_limpiar();
    terminal_desactivar_modo_raw();
    printf("Buscar palabra: "); fflush(stdout);
    char termino[128];
    if (fgets(termino, sizeof(termino), stdin) != NULL) {
        size_t len = strlen(termino);
        if (len > 0 && termino[len-1] == '\n') termino[len-1] = '\0';
        NodoLinea *encontrada = NULL;
        int posX = 0, posY = 0;
        if (estructura_buscar_palabra(e->estructura, termino, &encontrada, &posX, &posY)) {
            e->lineaActual = encontrada; e->cursorX = posX; e->cursorY = posY;
        } else {
            printf("\nLa palabra '%s' no se encuentra.\nPresione ENTER para continuar...", termino);
            fflush(stdout); getchar(); 
        }
    }
    terminal_activar_modo_raw();
}

// ============================================================================
// ENRUTADOR PRINCIPAL DE TECLAS (Dispatcher)
// ============================================================================

// Revisa si la tecla presionada es un atajo (Ctrl+S/Q/H/F o ':') y lo
// ejecuta. Retorna 1 si la consumio como comando, 0 si es texto normal.
int comando_manejar_teclado(char c, EstadoEditor *e) {
    
    // 1. Manejo de la vista de ayuda (Toggle)
    if (c == TECLA_CTRL('h')) { comando_toggle_ayuda(e); return 1; }

    // Bloquear el resto de comandos si el modal de ayuda esta abierto
    if (e->mostrarAyuda) {
        return 1;
    }
    
    // 2. Manejo de comandos de edición (Solo operan sobre el documento)
    switch (c) {
        case TECLA_CTRL('q'): comando_salir(e);      return 1;
        case TECLA_CTRL('s'): comando_guardar(e);    return 1;
        case TECLA_CTRL('f'): comando_buscar(e);     return 1;
        // NUEVO: ':' entra al modo de ordenes de la evaluacion (o/p/a/d/q/i/s/m/y/x)
        case ':':             ordenes_modo_interactivo(e); return 1;
    }
    
    // Retornamos 0 si el carácter ingresado no es un comando registrado
    return 0;
}
