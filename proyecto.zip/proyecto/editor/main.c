#include "editor.h"
#include "terminal.h"
#include <stdio.h> // Para constantes y tipos básicos estándar como NULL

/**
 * Punto de entrada del editor: activa el modo raw de la terminal,
 * inicializa el estado en memoria y entra al bucle principal
 * (dibujar pantalla -> leer una tecla -> repetir).
 */
int main(int argc, char *argv[]) {
    terminal_activar_modo_raw(); // el kernel deja de procesar el teclado por lineas

    EstadoEditor editor;
    const char* archivo_a_abrir = (argc >= 2) ? argv[1] : NULL;
    editor_inicializar(&editor, archivo_a_abrir);

    editor_pantalla_bienvenida(&editor);

    while (1) {
        editor_refrescar_pantalla(&editor); // dibuja el estado actual en pantalla
        editor_procesar_tecla(&editor);     // bloquea esperando la siguiente tecla (read())
    }

    editor_liberar(&editor);
    return 0;
}
