#include "editor.h"
#include "terminal.h"
#include "comando.h" // Incluimos el nuevo manejador de comandos
#include <unistd.h> // Para llamadas al sistema POSIX como read(), write(), isatty() y constantes STDIN_FILENO, STDOUT_FILENO
#include <stdlib.h> // Para funciones estándar del sistema como malloc(), free(), exit()
#include <stdio.h>  // Para printf, getchar, fgets, sscanf (solo E/S estandar por consola, no de archivos)
#include <string.h> // Para manipulación de strings y bloques de memoria (strlen, strcpy, strncmp, strchr, etc.)
#include <fcntl.h>  // Para open() y sus flags (O_RDWR, O_CREAT) usados por el fd persistente del modo de órdenes

// Limpia la pantalla y reposiciona el cursor, escribiendo codigos ANSI
// directamente a STDOUT_FILENO (syscall write()).
void editor_pantalla_limpiar(void) {
    write(STDOUT_FILENO, "\x1b[2J", 4);
    write(STDOUT_FILENO, "\x1b[H", 3);
    write(STDOUT_FILENO, TEMA_FONDO, strlen(TEMA_FONDO));
    write(STDOUT_FILENO, TEMA_TEXTO, strlen(TEMA_TEXTO));
}

// Muestra el ASCII art de bienvenida centrado, 5 segundos. Se salta si no
// hay una terminal real (isatty()==0) o si EAFIT_EDITOR_SIN_SPLASH esta
// definida (asi la usan las pruebas automatizadas en PRUEBAS.sh).
void editor_pantalla_bienvenida(EstadoEditor *e) {
    if (!isatty(STDIN_FILENO) || getenv("EAFIT_EDITOR_SIN_SPLASH") != NULL) return;

    editor_pantalla_limpiar();
    
    char *ascii_art[] = {
        "███████╗██████╗ ██╗████████╗ ██████╗ ██████╗ ",
        "██╔════╝██╔══██╗██║╚══██╔══╝██╔═══██╗██╔══██╗",
        "█████╗  ██║  ██║██║   ██║   ██║   ██║██████╔╝",
        "██╔══╝  ██║  ██║██║   ██║   ██║   ██║██╔══██╗",
        "███████╗██████╔╝██║   ██║   ╚██████╔╝██║  ██║",
        "╚══════╝╚═════╝ ╚═╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝",
        "                                             ",
        "      ███████╗ █████╗ ███████╗██╗████████╗   ",
        "      ██╔════╝██╔══██╗██╔════╝██║╚══██╔══╝   ",
        "      █████╗  ███████║█████╗  ██║   ██║      ",
        "      ██╔══╝  ██╔══██║██╔══╝  ██║   ██║      ",
        "      ███████╗██║  ██║██║     ██║   ██║      ",
        "      ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝   ╚═╝      "
    };
    
    int num_lineas = 13;
    int ancho_visual = 45;

    int start_y = (e->filasPantalla / 2) - (num_lineas / 2);
    int start_x = (e->columnasPantalla / 2) - (ancho_visual / 2);

    char buf[64];
    write(STDOUT_FILENO, "\x1b[1;36m", 7);

    for (int i = 0; i < num_lineas; i++) {
        snprintf(buf, sizeof(buf), "\x1b[%d;%dH", start_y + i, start_x);
        write(STDOUT_FILENO, buf, strlen(buf));
        write(STDOUT_FILENO, ascii_art[i], strlen(ascii_art[i]));
    }

    write(STDOUT_FILENO, "\x1b[0m", 4);
    sleep(5); // syscall: pausa 5s antes de entrar al editor
}

static void configurar_archivo(EstadoEditor *e, const char* nombreArchivo) {
    char *log_syscall = malloc(65536);
    log_syscall[0] = '\0';
    
    if (nombreArchivo) {
        e->nombreArchivo = malloc(strlen(nombreArchivo) + 1);
        strcpy(e->nombreArchivo, nombreArchivo);
        estructura_cargar_archivo(e->estructura, nombreArchivo, log_syscall);
        // Se omite igual que el splash durante las pruebas automatizadas.
        if (strlen(log_syscall) > 0 && isatty(STDIN_FILENO) && getenv("EAFIT_EDITOR_SIN_SPLASH") == NULL) {
            comando_mostrar_log_sistema("REPORTE DETALLADO (CARGAR ARCHIVO)", log_syscall);
        }
    } else {
        e->nombreArchivo = malloc(strlen("archivo.txt") + 1);
        strcpy(e->nombreArchivo, "archivo.txt");
    }
    free(log_syscall);
}

void editor_reposicionar_cursor_final(EstadoEditor *e) {
    e->lineaActual = e->estructura->cola;
    e->cursorY = e->estructura->totalLineas > 0 ? e->estructura->totalLineas - 1 : 0;
    e->cursorX = e->lineaActual ? e->lineaActual->longitud : 0;
}

void editor_inicializar(EstadoEditor *e, const char* nombreArchivo) {
    e->cursorX = 0;
    e->cursorY = 0;
    e->estructura = estructura_crear();
    e->desplazamientoFila = 0;
    e->mostrarAyuda = 0;
    e->fdArchivo = -1;
    configurar_archivo(e, nombreArchivo);
    editor_reposicionar_cursor_final(e);
    if (terminal_obtener_tamano(&e->filasPantalla, &e->columnasPantalla) == -1) {
        e->filasPantalla = 24; e->columnasPantalla = 80;
    }

    // Si arrancamos con un archivo, dejamos abierto un fd persistente
    // (open con O_RDWR|O_CREAT) para que el modo de ordenes (':') pueda
    // usar 'p', 'a', 'm', etc. sin tener que escribir 'o archivo.txt' antes.
    if (nombreArchivo) {
        e->fdArchivo = open(nombreArchivo, O_RDWR | O_CREAT, 0644);
    }
}

void editor_liberar(EstadoEditor *e) {
    estructura_destruir(e->estructura);
    if (e->nombreArchivo) free(e->nombreArchivo);
    if (e->fdArchivo != -1) close(e->fdArchivo);
}

static void pantalla_ajustar_scroll(EstadoEditor *e) {
    if (e->cursorY < e->desplazamientoFila) e->desplazamientoFila = e->cursorY;
    if (e->cursorY >= e->desplazamientoFila + e->filasPantalla - 1) {
        e->desplazamientoFila = e->cursorY - e->filasPantalla + 2;
    }
}

static void pantalla_dibujar_linea(NodoLinea *linea) {
    NodoPalabra *pal = linea->palabras_cabeza;
    while (pal) { write(STDOUT_FILENO, pal->texto, pal->longitud); pal = pal->siguiente; }
}

static void pantalla_dibujar_todas_las_filas(EstadoEditor *e) {
    NodoLinea *actual = e->estructura->cabeza;
    for (int i = 0; i < e->desplazamientoFila && actual != NULL; i++) actual = actual->siguiente;
    for (int y = 0; y < e->filasPantalla - 1; y++) {
        if (actual) { pantalla_dibujar_linea(actual); actual = actual->siguiente; } 
        else { write(STDOUT_FILENO, TEMA_LINEA_VACIA, strlen(TEMA_LINEA_VACIA)); }
        write(STDOUT_FILENO, "\r\n", 2);
    }
}

// Dibuja la barra inferior: nombre del archivo, posicion del cursor y los
// atajos disponibles. Se trunca si la terminal es mas angosta que el texto.
static void pantalla_dibujar_barra_estado(EstadoEditor *e) {
    char estado[1024];
    char *comandos = " Ctrl-S(Guarda) | Ctrl-Q(Salir) | Ctrl-H(Ayuda) | Ctrl-F(Buscar) | :(Ordenes o/p/a/d/q/i/s/m/y/x)";

    int len_estado = snprintf(estado, sizeof(estado),
        " [Editor EAFIT] Archivo: %s | Fila: %d, Col: %d |%s",
        e->nombreArchivo ? e->nombreArchivo : "[Nuevo]",
        e->cursorY + 1, e->cursorX + 1, comandos);

    write(STDOUT_FILENO, TEMA_BARRA_ESTADO, strlen(TEMA_BARRA_ESTADO));

    int len = len_estado;
    int max_col = e->columnasPantalla;
    if (len > max_col) len = max_col;

    write(STDOUT_FILENO, estado, len);
    while (len < max_col) { write(STDOUT_FILENO, " ", 1); len++; }

    write(STDOUT_FILENO, TEMA_RESTAURAR, strlen(TEMA_RESTAURAR));
    write(STDOUT_FILENO, TEMA_FONDO, strlen(TEMA_FONDO));
    write(STDOUT_FILENO, TEMA_TEXTO, strlen(TEMA_TEXTO));
}

static void pantalla_posicionar_cursor(EstadoEditor *e) {
    char buf[32];
    snprintf(buf, sizeof(buf), "\x1b[%d;%dH", (e->cursorY - e->desplazamientoFila) + 1, e->cursorX + 1);
    write(STDOUT_FILENO, buf, strlen(buf));
}

void editor_refrescar_pantalla(EstadoEditor *e) {
    editor_pantalla_limpiar();
    
    if (comando_dibujar_modal(e)) return; // hay un modal activo (ej. ayuda): no dibujar el texto
    
    pantalla_ajustar_scroll(e);
    pantalla_dibujar_todas_las_filas(e);
    pantalla_dibujar_barra_estado(e);
    pantalla_posicionar_cursor(e);
}

void editor_mover_cursor(EstadoEditor *e, char tecla) {
    switch (tecla) {
        case 'A': case 'w':
            if (e->cursorY > 0 && e->lineaActual->anterior) {
                e->cursorY--; e->lineaActual = e->lineaActual->anterior;
                if ((size_t)e->cursorX > e->lineaActual->longitud) e->cursorX = e->lineaActual->longitud;
            } break;
        case 'B': case 's':
            if (e->lineaActual->siguiente) {
                e->cursorY++; e->lineaActual = e->lineaActual->siguiente;
                if ((size_t)e->cursorX > e->lineaActual->longitud) e->cursorX = e->lineaActual->longitud;
            } break;
        case 'C': case 'd':
            if ((size_t)e->cursorX < e->lineaActual->longitud) e->cursorX++;
            break;
        case 'D': case 'a':
            if (e->cursorX > 0) e->cursorX--;
            break;
    }
}

static void manejar_escritura(char c, EstadoEditor *e) {
    if (c == '\r' || c == '\n') {
        e->lineaActual = estructura_insertar_linea(e->estructura, e->lineaActual);
        e->cursorX = 0; e->cursorY++;
    } else if (c == 127) { 
        if (e->cursorX > 0) { linea_eliminar_caracter(e->lineaActual, e->cursorX - 1); e->cursorX--; }
    } else if (c >= 32 && c <= 126) {
        linea_insertar_caracter(e->lineaActual, e->cursorX, c); e->cursorX++;
    }
}

// Lee una tecla (bloquea en read() hasta que llega) y la despacha: primero
// a comando.c (atajos Ctrl+?), luego a flechas, y si no es nada de eso, la
// trata como texto normal a insertar.
void editor_procesar_tecla(EstadoEditor *e) {
    char c = '\0';
    ssize_t leido = read(STDIN_FILENO, &c, 1);
    if (leido <= 0) {
        // EOF o error (p. ej. se acabo la entrada en una prueba automatizada)
        editor_liberar(e); // cierra fdArchivo y libera la lista enlazada antes de salir
        exit(0);
    }
    
    // Delegar el procesamiento de comandos de control al nuevo módulo
    if (comando_manejar_teclado(c, e)) return;
    
    if (c == '\x1b') { 
        char seq[3];
        if (read(STDIN_FILENO, &seq[0], 1) == 0) return;
        if (read(STDIN_FILENO, &seq[1], 1) == 0) return;
        if (seq[0] == '[') editor_mover_cursor(e, seq[1]);
        return;
    } 
    manejar_escritura(c, e);
}
