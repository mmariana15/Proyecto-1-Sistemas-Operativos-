#ifndef ORDENES_H
#define ORDENES_H

#include "editor.h"

// Modulo: modo de ordenes (o/p/a/d/q/i/s/m/y/x). Se activa con ':' dentro
// del editor visual (como en vi). Cada orden usa syscalls de bajo nivel
// (open/read/write/lseek/ftruncate/fstat/close) sobre el fd persistente
// del editor, y recarga la vista visual despues de cada cambio.
void ordenes_modo_interactivo(EstadoEditor *e);

#endif
