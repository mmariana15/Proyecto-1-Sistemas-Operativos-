#define _GNU_SOURCE
#include <errno.h>
#include <pty.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

/* Driver de pruebas: abre <binario> en un pseudo-terminal real (necesario
 * porque el editor lee el teclado byte a byte en modo raw) y ejecuta un
 * guion de ordenes leido por stdin: SEND, SENDLN, SLEEP, EXPECT, WAITFOR.
 * Imprime toda la salida capturada y termina en 0 si todo se cumplio, 1 si no. */

/* ---------- buffer dinamico para el output acumulado ---------- */

typedef struct {
    char *data;
    size_t len;
    size_t cap;
} Buffer;

static void buf_init(Buffer *b) {
    b->cap = 65536;
    b->data = malloc(b->cap);
    b->len = 0;
    if (!b->data) { perror("malloc"); exit(1); }
}

static void buf_append(Buffer *b, const char *chunk, size_t n) {
    if (b->len + n > b->cap) {
        while (b->len + n > b->cap) b->cap *= 2;
        char *nuevo = realloc(b->data, b->cap);
        if (!nuevo) { perror("realloc"); exit(1); }
        b->data = nuevo;
    }
    memcpy(b->data + b->len, chunk, n);
    b->len += n;
}

static int buf_contains(const Buffer *b, const char *needle) {
    size_t nlen = strlen(needle);
    if (nlen == 0) return 1;
    if (b->len < nlen) return 0;
    return memmem(b->data, b->len, needle, nlen) != NULL;
}

/* ---------- lectura no bloqueante con timeout, igual que read_available() ---------- */

static double now_seconds(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

static void read_available(int fd, double timeout, Buffer *out) {
    char chunk[65536];
    for (;;) {
        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(fd, &rfds);
        struct timeval tv;
        tv.tv_sec = (time_t)timeout;
        tv.tv_usec = (suseconds_t)((timeout - (double)tv.tv_sec) * 1e6);
        int r = select(fd + 1, &rfds, NULL, NULL, &tv);
        if (r <= 0) break; /* timeout o error: no hay mas datos por ahora */
        ssize_t n = read(fd, chunk, sizeof(chunk));
        if (n <= 0) break; /* EOF o error */
        buf_append(out, chunk, (size_t)n);
    }
}

/* ---------- escritura simple, reintentando ante escrituras parciales ---------- */

static void write_all(int fd, const char *data, size_t len) {
    size_t off = 0;
    while (off < len) {
        ssize_t n = write(fd, data + off, len - off);
        if (n < 0) {
            if (errno == EINTR) continue;
            break;
        }
        off += (size_t)n;
    }
}

/* ---------- lectura completa de stdin (el guion) ---------- */

static char *read_all_stdin(void) {
    size_t cap = 65536, len = 0;
    char *data = malloc(cap);
    if (!data) { perror("malloc"); exit(1); }
    for (;;) {
        if (len == cap) {
            cap *= 2;
            char *nuevo = realloc(data, cap);
            if (!nuevo) { perror("realloc"); exit(1); }
            data = nuevo;
        }
        ssize_t n = read(STDIN_FILENO, data + len, cap - len - 1);
        if (n < 0) { if (errno == EINTR) continue; perror("read stdin"); exit(1); }
        if (n == 0) break;
        len += (size_t)n;
    }
    data[len] = '\0';
    return data;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Uso: %s <binario> [args...] < guion.txt\n", argv[0]);
        return 2;
    }

    char *guion = read_all_stdin();

    int master_fd;
    pid_t pid = forkpty(&master_fd, NULL, NULL, NULL);
    if (pid < 0) {
        perror("forkpty");
        return 1;
    }
    if (pid == 0) {
        execvp(argv[1], &argv[1]);
        _exit(127);
    }

    Buffer full_output;
    buf_init(&full_output);
    int ok = 1;

    /* Dar tiempo a que arranque */
    read_available(master_fd, 0.5, &full_output);

    /* Procesar el guion linea por linea (igual que str.splitlines()) */
    char *saveptr = NULL;
    char *linea = strtok_r(guion, "\n", &saveptr);
    while (linea != NULL) {
        size_t llen = strlen(linea);
        if (llen > 0 && linea[llen - 1] == '\r') { linea[llen - 1] = '\0'; llen--; }

        if (llen == 0 || linea[0] == '#') {
            linea = strtok_r(NULL, "\n", &saveptr);
            continue;
        }

        char *sp = strchr(linea, ' ');
        char *op = linea;
        char *arg = "";
        if (sp != NULL) {
            *sp = '\0';
            arg = sp + 1;
        }

        if (strcmp(op, "WAITFOR") == 0) {
            double deadline = now_seconds() + 8.0;
            while (!buf_contains(&full_output, arg)) {
                if (now_seconds() > deadline) {
                    fprintf(stderr, "[FALLO] WAITFOR agoto el tiempo: '%s'\n", arg);
                    ok = 0;
                    break;
                }
                read_available(master_fd, 0.2, &full_output);
            }
        } else if (strcmp(op, "SEND") == 0) {
            write_all(master_fd, arg, strlen(arg));
        } else if (strcmp(op, "SENDLN") == 0) {
            write_all(master_fd, arg, strlen(arg));
            write_all(master_fd, "\n", 1);
        } else if (strcmp(op, "SLEEP") == 0) {
            double secs = atof(arg);
            struct timespec ts;
            ts.tv_sec = (time_t)secs;
            ts.tv_nsec = (long)((secs - (double)ts.tv_sec) * 1e9);
            nanosleep(&ts, NULL);
        } else if (strcmp(op, "EXPECT") == 0) {
            read_available(master_fd, 1.0, &full_output);
            if (!buf_contains(&full_output, arg)) {
                fprintf(stderr, "[FALLO] No se encontro: '%s'\n", arg);
                ok = 0;
            }
        } else {
            fprintf(stderr, "[AVISO] Operacion desconocida: %s\n", op);
        }

        read_available(master_fd, 0.2, &full_output);
        linea = strtok_r(NULL, "\n", &saveptr);
    }

    read_available(master_fd, 1.0, &full_output);

    kill(pid, SIGKILL);
    waitpid(pid, NULL, 0);

    fwrite(full_output.data, 1, full_output.len, stdout);
    fflush(stdout);

    free(full_output.data);
    free(guion);

    return ok ? 0 : 1;
}
