#!/bin/bash
# ============================================================================
# Script de Pruebas Automatizado - Editor de Texto en Unix (SO2026B, EAFIT)
# ============================================================================
# El editor lee el teclado byte a byte en "modo raw" (como vi/nano), asi que
# estas pruebas lo manejan a traves de un pseudo-terminal real (tests/pty_driver.c)
# en vez de una simple tuberia: se envian teclas, se espera (WAITFOR) a que el
# programa responda, y se verifica tanto lo que aparece en pantalla como el
# contenido real del archivo en disco.
#
# La variable EAFIT_EDITOR_SIN_SPLASH desactiva, solo durante estas pruebas,
# la animacion de bienvenida (5s) y el modal de "reporte de carga" al abrir un
# archivo -- ambos pensados para un humano interactivo, no para un script.
# ============================================================================

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DRIVER="$ROOT_DIR/tests/pty_driver"
EDITOR_BIN="$ROOT_DIR/editor/text_editor"
SHELL_BIN="$ROOT_DIR/shell/eafitOS"
TEST_DIR="/tmp/prueba_editor_so_$$"
mkdir -p "$TEST_DIR"
export EAFIT_EDITOR_SIN_SPLASH=1

TOTAL=0
PASSED=0

pass() { PASSED=$((PASSED+1)); echo "  [OK] $1"; }
fail() { echo "  [FALLO] $1"; }

# ejecutar_guion <archivo_de_prueba> <guion via stdin>
# Corre el editor sobre <archivo_de_prueba sobre una pty, alimentandolo con el
# guion recibido por stdin. Devuelve 0 si todos los WAITFOR del guion se
# cumplieron (ver tests/pty_driver.c para el formato del guion).
ejecutar_guion() {
    local archivo="$1"
    timeout 25 "$DRIVER" env EAFIT_EDITOR_SIN_SPLASH=1 "$EDITOR_BIN" "$archivo"
}

verificar_archivo() {
    # verificar_archivo <nombre_prueba> <archivo> <contenido_exacto_esperado>
    TOTAL=$((TOTAL+1))
    local actual
    actual="$(cat "$2" 2>/dev/null)"
    if [ "$actual" = "$3" ]; then
        pass "$1"
    else
        fail "$1"
        echo "      esperado: $(printf '%q' "$3")"
        echo "      obtenido: $(printf '%q' "$actual")"
    fi
}

echo "=================================================================="
echo " 1. COMPILACION"
echo "=================================================================="
(cd "$ROOT_DIR/editor" && make clean >/dev/null 2>&1; make) || { echo "FALLÓ la compilación del editor"; exit 1; }
(cd "$ROOT_DIR/shell"  && make clean >/dev/null 2>&1; make >/dev/null 2>&1 <<< "exit") || { echo "FALLÓ la compilación del shell"; exit 1; }
gcc -Wall -Wextra -O2 -o "$DRIVER" "$ROOT_DIR/tests/pty_driver.c" -lutil || { echo "FALLÓ la compilación del driver de pruebas (tests/pty_driver.c)"; exit 1; }
echo "Compilación OK (editor/text_editor, shell/eafitOS, tests/pty_driver)"
echo

echo "=================================================================="
echo " 2. COMANDOS BASE (o, p, a, d, q)"
echo "=================================================================="
F="$TEST_DIR/base.txt"
rm -f "$F"
TOTAL=$((TOTAL+1))
if ejecutar_guion "$F" <<'GUION' > "$TEST_DIR/base.out" 2>"$TEST_DIR/base.err"
WAITFOR Archivo:
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN a "Primera linea"
WAITFOR Linea anadida correctamente
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN a "Segunda linea"
WAITFOR Linea anadida correctamente
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN a "Tercera linea"
WAITFOR Linea anadida correctamente
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN p 2
WAITFOR Linea 2: Segunda linea
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN d 2
WAITFOR borrada correctamente
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN q
WAITFOR Cerrando editor
GUION
then
    pass "secuencia o(implicito)+a+p+d+q via modo de ordenes"
else
    fail "secuencia o(implicito)+a+p+d+q via modo de ordenes (ver $TEST_DIR/base.err)"
    cat "$TEST_DIR/base.err"
fi
verificar_archivo "archivo final tras a+a+a+d 2" "$F" $'Primera linea\nTercera linea'
echo

echo "=================================================================="
echo " 3. NIVEL 2 (i, s)"
echo "=================================================================="
F="$TEST_DIR/nivel2.txt"
rm -f "$F"
TOTAL=$((TOTAL+1))
if ejecutar_guion "$F" <<'GUION' > "$TEST_DIR/n2.out" 2>"$TEST_DIR/n2.err"
WAITFOR Archivo:
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN a "Primera"
WAITFOR Linea anadida correctamente
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN a "Tercera"
WAITFOR Linea anadida correctamente
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN i 2 "Segunda"
WAITFOR insertada correctamente
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN s Primera
WAITFOR Linea 1: Primera
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN s inexistente
WAITFOR No se encontraron resultados
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN q
WAITFOR Cerrando editor
GUION
then
    pass "secuencia a+a+i+s(encontrada)+s(sin resultados)+q"
else
    fail "secuencia a+a+i+s+q (ver $TEST_DIR/n2.err)"
    cat "$TEST_DIR/n2.err"
fi
verificar_archivo "archivo final tras insertar linea 2" "$F" $'Primera\nSegunda\nTercera'
echo

echo "=================================================================="
echo " 4. NIVEL 3 (m, y, x)"
echo "=================================================================="
F="$TEST_DIR/nivel3.txt"
rm -f "$F"
TOTAL=$((TOTAL+1))
if ejecutar_guion "$F" <<'GUION' > "$TEST_DIR/n3.out" 2>"$TEST_DIR/n3.err"
WAITFOR Archivo:
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN a "Primera"
WAITFOR Linea anadida correctamente
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN a "Segunda"
WAITFOR Linea anadida correctamente
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN a "Tercera"
WAITFOR Linea anadida correctamente
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN m
WAITFOR Inodo:
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN y 1
WAITFOR copiada al portapapeles
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN x 3
WAITFOR pegada en la linea 3
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN q
WAITFOR Cerrando editor
GUION
then
    pass "secuencia a+a+a+m+y+x+q"
else
    fail "secuencia a+a+a+m+y+x+q (ver $TEST_DIR/n3.err)"
    cat "$TEST_DIR/n3.err"
fi
verificar_archivo "archivo final tras yank(1)+paste(3)" "$F" $'Primera\nSegunda\nPrimera\nTercera'
echo

echo "=================================================================="
echo " 5. MANEJO DE ERRORES Y CASOS BORDE"
echo "=================================================================="
# 5a. Archivo vacio (0 bytes) + n invalido (0, negativo por atoi) + n inexistente + portapapeles vacio
F="$TEST_DIR/errores.txt"
rm -f "$F"
TOTAL=$((TOTAL+1))
if ejecutar_guion "$F" <<'GUION' > "$TEST_DIR/err.out" 2>"$TEST_DIR/err.err"
WAITFOR Archivo:
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN p
WAITFOR Fin del archivo
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN p 0
WAITFOR Numero de linea invalido
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN d 0
WAITFOR Numero de linea invalido
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN p 99
WAITFOR no existe en el archivo
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN x 1
WAITFOR Portapapeles vacio
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN q
WAITFOR Cerrando editor
GUION
then
    pass "archivo vacio + n=0 (p y d) + linea inexistente + x sin yank previo"
else
    fail "manejo de errores (ver $TEST_DIR/err.err)"
    cat "$TEST_DIR/err.err"
fi
echo

# 5b. Ultima linea del archivo SIN salto de linea final (caso borde comun al
# leer archivos de texto reales, que no siempre terminan en salto de linea).
F2="$TEST_DIR/sin_salto.txt"
printf 'Linea sin salto final' > "$F2"
TOTAL=$((TOTAL+1))
if ejecutar_guion "$F2" <<'GUION' > "$TEST_DIR/sinsalto.out" 2>"$TEST_DIR/sinsalto.err"
WAITFOR Archivo:
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN p 1
WAITFOR Linea 1: Linea sin salto final
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN a "Segunda linea"
WAITFOR Linea anadida correctamente
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN q
WAITFOR Cerrando editor
GUION
then
    pass "ultima linea sin salto de linea final se lee y se puede seguir editando"
else
    fail "caso borde sin salto de linea final (ver $TEST_DIR/sinsalto.err)"
    cat "$TEST_DIR/sinsalto.err"
fi
verificar_archivo "archivo con linea sin salto final, tras anadir otra linea" "$F2" $'Linea sin salto final\nSegunda linea'
echo

echo "=================================================================="
echo " 6. INTEGRACION CON EL SHELL (ed_open)"
echo "=================================================================="
F="$TEST_DIR/integracion.txt"
rm -f "$F"
TOTAL=$((TOTAL+1))
if (cd "$ROOT_DIR/shell" && timeout 25 "$DRIVER" env EAFIT_EDITOR_SIN_SPLASH=1 ./eafitOS) <<GUION > "$TEST_DIR/integ.out" 2>"$TEST_DIR/integ.err"
WAITFOR eafitOS>
SENDLN ed_open $F
WAITFOR Archivo:
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN a "Linea desde el shell"
WAITFOR Linea anadida correctamente
SENDLN
WAITFOR volver al editor
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN q
WAITFOR Control devuelto al shell
SENDLN exit
GUION
then
    pass "ed_open lanza el editor, se edita, y el shell recupera el control"
else
    fail "integracion con el shell (ver $TEST_DIR/integ.err)"
    cat "$TEST_DIR/integ.err"
fi
verificar_archivo "archivo editado a traves de ed_open persiste en disco" "$F" "Linea desde el shell"
echo

rm -rf "$TEST_DIR"

echo "=================================================================="
echo " RESUMEN: $PASSED / $TOTAL pruebas pasaron"
echo "=================================================================="
[ "$PASSED" -eq "$TOTAL" ]
