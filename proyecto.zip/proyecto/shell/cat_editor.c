#include "shell.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>

/**
 * ed_open [archivo] -- Abre el editor de texto desde el shell.
 *
 * El shell (padre) hace fork() para crear un proceso hijo. Ese hijo se
 * convierte en el editor llamando a execvp(), mientras el padre se queda
 * esperando con waitpid() a que termine para recuperar el prompt. Es el
 * mismo mecanismo que usa un shell real (bash) al abrir 'vi' o 'nano'.
 *
 * Syscalls: fork(2), execvp(3), waitpid(2)
 */
int cmd_ed_open(int argc, char **argv) {
    /* Ruta del binario del editor ya compilado (ajustar si cambian la estructura
     * de carpetas del proyecto). Se asume que 'shell' y 'editor' son carpetas
     * hermanas dentro de la raíz del proyecto. */
    const char *editor_path = "../editor/text_editor";

    char *exec_args[3];
    exec_args[0] = (char *)editor_path;
    exec_args[1] = (argc == 2) ? argv[1] : NULL;
    exec_args[2] = NULL;

    LOG_SYSCALL("fork", "");
    pid_t pid = fork();
    if (pid == -1) {
        LOG_SYSCALL_ERROR(strerror(errno));
        perror("fork");
        return 1;
    }

    if (pid == 0) {
        /* PROCESO HIJO: reemplaza su imagen por el binario del editor */
        LOG_SYSCALL("execvp", "\"%s\", argv", editor_path);
        printf("\n" COLOR_INFO "[Hijo] Cediendo el control de la terminal al editor de texto...\n\n" COLOR_RESET);
        /* execvp() no pasa por exit(), asi que vaciamos el buffer de stdout
         * antes de llamarlo para no perder mensajes pendientes. */
        fflush(stdout);
        execvp(editor_path, exec_args);

        /* Solo se llega aquí si execvp falló */
        LOG_SYSCALL_ERROR(strerror(errno));
        perror("execvp");
        fprintf(stderr, COLOR_ERROR "Error: no se pudo ejecutar '%s'. ¿Ya compilaste el editor (make en /editor)?\n" COLOR_RESET, editor_path);
        exit(127);
    } else {
        /* PROCESO PADRE (shell): espera a que el usuario cierre el editor con 'q' */
        LOG_SYSCALL_RESULT(pid);
        printf(COLOR_PROMPT "[Shell]" COLOR_RESET " Editor lanzado (PID %d). Esperando a que termine...\n", pid);

        int status;
        LOG_SYSCALL("waitpid", "%d, &status, 0", pid);
        pid_t waited = waitpid(pid, &status, 0);
        if (waited == -1) {
            LOG_SYSCALL_ERROR(strerror(errno));
            perror("waitpid");
            return 1;
        }
        LOG_SYSCALL_RESULT(waited);

        printf(COLOR_PROMPT "[Shell]" COLOR_RESET " Control devuelto al shell educativo.\n");
    }
    return 0;
}
